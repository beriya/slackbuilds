# Debian
How to build the debian package based on the `./debian` folder:
1. Install the build dependencies.
2. apt install debhelper
3. dpkg-buildpackage -B
